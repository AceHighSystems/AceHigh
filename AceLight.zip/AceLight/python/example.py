
import can
import acelight
from acelight.modules import ranger_mk1 as r


with can.Bus(
    interface="slcan",
    channel=CHANNEL,
    bitrate=BITRATE
) as bus:


    ace = acelight.Client(host_id=1, bus=bus)

    nodeID = 2

    status = ace.write(nodeID, r.profile_velocity, 1000) # set the velocity profile steps/seconds

    # Enable the motor driver
    status = ace.write(nodeID, r.mode, 1) # Set the Ranger operating mode. 1 = open loop step/dir mode active

    while True:
        status = ace.write(nodeID, r.step_move, 1000) # Move a certain amount of steps in one directions (+/-)
        status, data = ace.read(nodeID, r.angle) # Read the current angle in milli degrees