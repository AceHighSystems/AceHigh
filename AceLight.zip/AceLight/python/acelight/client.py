

class Client:
    def __init__(self, host_id, bus):
        # Store the Host ID in this particular client object.
        self.host_id = host_id
        self.bus = bus


    def read(self, node_id, parameter_id):
        bus = self.bus
        source_id = self.host_id
        destination_id = node_id

        # CAN message construction, transmission, and response handling
        # will go here.
        raise NotImplementedError("CAN read is not implemented yet")

    