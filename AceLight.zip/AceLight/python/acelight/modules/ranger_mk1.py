

from ..parameter import Parameter


node_id             = Parameter(id=0x02, data_type="U8")
step_move           = Parameter(id=0x41, data_type="I32")
target_position     = Parameter(id=0x42, data_type="I32")
voltage             = Parameter(id=0x80, data_type="I32")
current             = Parameter(id=0x81, data_type="I32")
temperature         = Parameter(id=0x82, data_type="I32")

# Continue with the remaining parameters.